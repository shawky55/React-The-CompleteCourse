import SimpleInput from './components/SimpleInput';

function App() {
  return (
    <div className="app">
      <SimpleInput />
    </div>
  );
}

export default App;
